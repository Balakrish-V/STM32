/*
 * SimpleKalmanFilter - a Kalman Filter implementation for single variable models.
 * Created by Denys Sene, January, 1, 2017.
 * Released under MIT License - see LICENSE file for details.
 */

#include "KalmanFilter.h"
#include <math.h>
#include <stdio.h>
float _err_measure;
float _err_estimate;
float _q;
float _current_estimate = 0;
float _last_estimate = 0;
float _kalman_gain = 0;

void beginKalmanFilter(float mea_e, float est_e, float q) {
	_err_measure = mea_e;
	_err_estimate = est_e;
	_q = q;
}

/*

A larger mea_e means the filter trusts the measurements less (i.e., the sensor is noisy).
A smaller mea_e means the filter trusts the measurements more (i.e., the sensor is reliable).
---->Small (sensor is good)

A larger est_e means the filter initially trusts its estimate less.
A smaller est_e means it trusts its estimate more.
---->Small (good prior)

A larger q means we expect more variability in the system, so the filter will adapt more quickly to changes.
A smaller q assumes the system is more stable, and the filter changes slowly.
---->Large (system changes quickly)


Parameter     | Typical Range    | Description
---------------------------------------------------------------
mea_e         | 0.01 to 5.0      | Measurement noise.
                                   Low for accurate sensors (e.g., 0.01–0.5),
                                   high for noisy ones (e.g., 1–5).

est_e         | 0.1 to 10.0      | Initial estimate uncertainty.
                                   Moderate default is 1.0.
                                   Use lower values if confident in the initial estimate.

q             | 0.0001 to 1.0    | Process noise.
                                   Small for stable systems (e.g., 0.001),
                                   larger for responsive/adaptive filters (e.g., 0.1–1.0).

*/

float updateEstimate(float mea) {
	_kalman_gain = _err_estimate / (_err_estimate + _err_measure);
	_current_estimate = _last_estimate + _kalman_gain * (mea - _last_estimate);
	_err_estimate = (1.0f - _kalman_gain) * _err_estimate+ fabsf(_last_estimate - _current_estimate) * _q;
	_last_estimate = _current_estimate;
	return _current_estimate;
}

void setMeasurementError(float mea_e) {
	_err_measure = mea_e;
}

void setEstimateError(float est_e) {
	_err_estimate = est_e;
}

void setProcessNoise(float q) {
	_q = q;
}

float getKalmanGain() {
	return _kalman_gain;
}

float getEstimateError() {
	return _err_estimate;
}
