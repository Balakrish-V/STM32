/*
 * Nextion_fns.c
 *
 *  Created on: Jan 20, 2025
 *      Author: user
 */

#include "Nextion_hdrs.h"
#include "main.h"
#include "string.h"
#include "stdio.h"
#include "stdbool.h"

extern UART_HandleTypeDef huart5;

extern bool nextion_flag;

uint8_t rev_init_bfr[6] = { 0 };

uint8_t Cmd_End[3] = { 0xFF, 0xFF, 0xFF };  // command end sequence

void Nextion_init(char *obj, uint8_t value) {
	char buf[20] = { 0 };
	int len = sprintf(buf, "%s=%u", obj, value);
	HAL_UART_Transmit(&huart5, (uint8_t*) buf, len, 1000);
	HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);
	HAL_UART_Receive(&huart5, rev_init_bfr, 5, HAL_MAX_DELAY);
	rev_init_bfr[5] = '\0';
	if (strcmp((char*) rev_init_bfr, "START") == 0) {
		nextion_flag = 1;
	}
}

void sendToMetalDetector(char *obj, uint16_t value) {
	char buf[30];
	int len = sprintf(buf, "%s=%u", obj, value);
	HAL_UART_Transmit(&huart5, (uint8_t*) buf, len, 1000);
	HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);
	memset(buf, 0, sizeof(buf));
}

void sendToBatterylevel(char *obj, uint16_t value) {
	char buf[30];
	int len = sprintf(buf, "%s=%u", obj, value);
	HAL_UART_Transmit(&huart5, (uint8_t*) buf, len, 1000);
	HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);
	memset(buf, 0, sizeof(buf));
}

void sendToBatteryPercentage(char *obj, uint16_t value) {
    char buf[30];
    char value_str[10];
    if (value > 100) {
        value = 100;
    }
    sprintf(value_str, "%u%%", value);
    int len = sprintf(buf, "%s=\"%s\"", obj, value_str);
    HAL_UART_Transmit(&huart5, (uint8_t*) buf, len, 1000);
    HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);
    memset(buf, 0, sizeof(buf));
}

void sendToLeak(char *obj, uint16_t value) {
	char buf[30];
	int len = sprintf(buf, "%s=%u", obj, value);
	HAL_UART_Transmit(&huart5, (uint8_t*) buf, len, 1000);
	HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);
	memset(buf, 0, sizeof(buf));
}

void sendToDepth(char *obj, char* value)
{
    char buf[30];
    int len = sprintf(buf, "%s=\"%s\"", obj, value);  // Add quotes around the value
    HAL_UART_Transmit(&huart5, (uint8_t *)buf, len, 1000);
    HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);
    memset(buf, 0, sizeof(buf));
}

void sendToAltitude(char *obj, char* value)
{
    char buf[30];
    int len = sprintf(buf, "%s=\"%s\"", obj, value);  // Add quotes around the value
    HAL_UART_Transmit(&huart5, (uint8_t *)buf, len, 1000);
    HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);
    memset(buf, 0, sizeof(buf));
}

