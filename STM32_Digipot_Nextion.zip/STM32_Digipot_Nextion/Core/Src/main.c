/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "Nextion_hdrs.h"
#include "ad5263_header.h"
#include "Utilities_MD.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

#define UART_BUFFER_SIZE 20
#define DEBUG_MSG_SIZE 128

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

I2C_HandleTypeDef hi2c3;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;

/* USER CODE BEGIN PV */

AD5263_t potentiometer = { 0 };
uint8_t uart4_rx_buffer[RX_BUFFER_SIZE] = { 0 };
uint8_t range = 0, delay = 0;

uint8_t mapped_percentage = 0;
static int adc_value = 0;
static int adc_prev_value = 0;
int filtered_value = 0;
int adc_max = 0, adc_min = 4095;
uint32_t adc_sum = 0;
uint32_t adc_avg = 0;
static int adc_buffer[ADC_BUFFER_SIZE] = { 0 }; // ADC buffer to store previous samples

//Leak Detection
GPIO_PinState leakDetected = 0;

//FLAGS
bool MET_ETH_Var = 0;
bool bt_flag = 0;
bool nextion_flag = 0;
bool dist_flag = 0;
bool depth_flag = 0;
bool zeroSent = 0;
bool zeroSent_Metal = 0;
bool zeroSent_Depth = 0;
bool zeroSent_Dist = 0;

static int variable1 = 0;
static int MetalV = 0;
static int map_met = 0;
static int prev_variable1 = 0;
static int prev_MetalV = 0;
static int prev_map_met = 0;
static char Depth_value[5] = { 0 };
static char Dist_value[5] = { 0 };
static char prev_Depth_value[5] = { 0 };
static char prev_Dist_value[5] = { 0 };

//UART_Interrupt_Callback
static char uart_buffer[UART_BUFFER_SIZE] = { 0 };

static char rx_char = 0;

int gpio_state = 0;

static int stablized_val = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
static void MX_ADC1_Init(void);
static void MX_I2C3_Init(void);
/* USER CODE BEGIN PFP */
void process_metal_detection(void);
void process_battery_level(void);
void process_depth_measurement(void);
void process_altitude_measurement(void);
void check_leak_detection(void);
int adaptive_diff(int adc_value);
int filter_noise(int new_sample);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int apply_weighted_filter(int new_sample) {
	for (int i = ADC_BUFFER_SIZE - 1; i > 0; i--) {
		adc_buffer[i] = adc_buffer[i - 1];
	}
	adc_buffer[0] = new_sample;

	int result = (24 * adc_buffer[0] + 16 * adc_buffer[1] + 8 * adc_buffer[2]
			+ 4 * adc_buffer[3] + 2 * adc_buffer[4] + 1 * adc_buffer[5]) / 51; //scaled weights = 51

	return result;  // Return the filtered value
}

void stabilize_oscillations_in_battery(int *number) {
	// initialize the stabilized value the first
	if (stablized_val == 0) {
		stablized_val = *number;
	}

	// if the current value is smaller than the stabilized value
	if (*number < stablized_val) {
		stablized_val = *number;
	}

	// set the number to the current stabilized value if not less than previous value
	*number = stablized_val;
}

void process_uart_data(char *data) {
	if (data[0] == '0') {
		switch (data[1]) {
		case '1':
			/*
			 data	 01 65.23
			 index	 12345678
			 */
			float value01 = atof(data + 3);
			variable1 = (int) value01;
			stabilize_oscillations_in_battery(&variable1);
			bt_flag = 1;
			zeroSent = 0; //for the next iteration
			break;
		case '3':
			set_gpio_high();    // Metal Detector ON
			zeroSent_Metal = 0; // next time else has to execute only once if stopped from QT
			break;
		case '4':
			set_gpio_low();   // Metal Detector OFF
			prev_MetalV = 0;
			prev_map_met = 0;
			break;
		case '5':
			bt_flag = 0;
			break;
		case '6':
			float value02 = atof(data + 3);
			char tempDist_value[5];
			sprintf(tempDist_value, "%0.2f", value02);

			if (strcmp(tempDist_value, prev_Dist_value) != 0) {
				strcpy(Dist_value, tempDist_value);
				strcpy(prev_Dist_value, tempDist_value);
				dist_flag = 1;
			};
			zeroSent_Dist = 0;  //next time else has to execute only once if stopped from QT
			break;
		case '7':
			float value03 = atof(data + 3);
			char tempDepth_value[5];
			sprintf(tempDepth_value, "%0.2f", value03);

			if (strcmp(tempDepth_value, prev_Depth_value) != 0) {
				strcpy(Depth_value, tempDepth_value);
				strcpy(prev_Depth_value, tempDepth_value);
				depth_flag = 1;
			}
			zeroSent_Depth = 0;  //next time else has to execute only once if stopped from QT
			break;
		case '8':
			dist_flag = 0;
			break;
		case '9':
			depth_flag = 0;
			break;
		default:
			return;
		}
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	if (huart->Instance == UART4) {
		static int index = 0;
		if (rx_char != '\n' && index < UART_BUFFER_SIZE - 1) {
			uart_buffer[index++] = rx_char;
		} else {
			uart_buffer[index] = '\0';
			index = 0;
			process_uart_data((char*) &uart_buffer);
		}
		HAL_UART_Receive_IT(&huart4, (uint8_t*) &rx_char, 1);
	}
}

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {

	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */
	HAL_Delay(3500);
	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_UART4_Init();
	MX_UART5_Init();
	MX_ADC1_Init();
	MX_I2C3_Init();
	/* USER CODE BEGIN 2 */
	AD5263_I2C_Init();
	AD5263_Write(&potentiometer, 0, 0);
	Nextion_init("Init.val", 1);
	HAL_UART_Receive_IT(&huart4, (uint8_t*) &rx_char, 1);
	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {
		HAL_Delay(300);
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
		HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
		if (nextion_flag) {
			check_leak_detection();
			process_metal_detection();
			process_battery_level();
			//Distance(in QT Terms) ~= Altitude(in STM32 Terms)
			process_depth_measurement();
			process_altitude_measurement();
		}
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
		Error_Handler();
	}
}

/**
 * @brief ADC1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_ADC1_Init(void) {

	/* USER CODE BEGIN ADC1_Init 0 */

	/* USER CODE END ADC1_Init 0 */

	ADC_ChannelConfTypeDef sConfig = { 0 };

	/* USER CODE BEGIN ADC1_Init 1 */

	/* USER CODE END ADC1_Init 1 */

	/** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	 */
	hadc1.Instance = ADC1;
	hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
	hadc1.Init.Resolution = ADC_RESOLUTION_12B;
	hadc1.Init.ScanConvMode = DISABLE;
	hadc1.Init.ContinuousConvMode = DISABLE;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1.Init.NbrOfConversion = 1;
	hadc1.Init.DMAContinuousRequests = DISABLE;
	hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	if (HAL_ADC_Init(&hadc1) != HAL_OK) {
		Error_Handler();
	}

	/** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	 */
	sConfig.Channel = ADC_CHANNEL_14;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN ADC1_Init 2 */

	/* USER CODE END ADC1_Init 2 */

}

/**
 * @brief I2C3 Initialization Function
 * @param None
 * @retval None
 */
static void MX_I2C3_Init(void) {

	/* USER CODE BEGIN I2C3_Init 0 */

	/* USER CODE END I2C3_Init 0 */

	/* USER CODE BEGIN I2C3_Init 1 */

	/* USER CODE END I2C3_Init 1 */
	hi2c3.Instance = I2C3;
	hi2c3.Init.ClockSpeed = 100000;
	hi2c3.Init.DutyCycle = I2C_DUTYCYCLE_2;
	hi2c3.Init.OwnAddress1 = 0;
	hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	hi2c3.Init.OwnAddress2 = 0;
	hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&hi2c3) != HAL_OK) {
		Error_Handler();
	}

	/** Configure Analogue filter
	 */
	if (HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE)
			!= HAL_OK) {
		Error_Handler();
	}

	/** Configure Digital filter
	 */
	if (HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN I2C3_Init 2 */

	/* USER CODE END I2C3_Init 2 */

}

/**
 * @brief UART4 Initialization Function
 * @param None
 * @retval None
 */
static void MX_UART4_Init(void) {

	/* USER CODE BEGIN UART4_Init 0 */

	/* USER CODE END UART4_Init 0 */

	/* USER CODE BEGIN UART4_Init 1 */

	/* USER CODE END UART4_Init 1 */
	huart4.Instance = UART4;
	huart4.Init.BaudRate = 9600;
	huart4.Init.WordLength = UART_WORDLENGTH_8B;
	huart4.Init.StopBits = UART_STOPBITS_1;
	huart4.Init.Parity = UART_PARITY_NONE;
	huart4.Init.Mode = UART_MODE_TX_RX;
	huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart4.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart4) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN UART4_Init 2 */

	/* USER CODE END UART4_Init 2 */

}

/**
 * @brief UART5 Initialization Function
 * @param None
 * @retval None
 */
static void MX_UART5_Init(void) {

	/* USER CODE BEGIN UART5_Init 0 */

	/* USER CODE END UART5_Init 0 */

	/* USER CODE BEGIN UART5_Init 1 */

	/* USER CODE END UART5_Init 1 */
	huart5.Instance = UART5;
	huart5.Init.BaudRate = 9600;
	huart5.Init.WordLength = UART_WORDLENGTH_8B;
	huart5.Init.StopBits = UART_STOPBITS_1;
	huart5.Init.Parity = UART_PARITY_NONE;
	huart5.Init.Mode = UART_MODE_TX_RX;
	huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart5.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart5) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN UART5_Init 2 */

	/* USER CODE END UART5_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };
	/* USER CODE BEGIN MX_GPIO_Init_1 */
	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, AD0_Pin | DIS_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOC, AD1_Pin | MET_PWR_ENABLE_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, LED1_Pin | LED2_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pins : AD0_Pin DIS_Pin */
	GPIO_InitStruct.Pin = AD0_Pin | DIS_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pin : AD1_Pin */
	GPIO_InitStruct.Pin = AD1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(AD1_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pin : LEAK_PIN_Pin */
	GPIO_InitStruct.Pin = LEAK_PIN_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;
	HAL_GPIO_Init(LEAK_PIN_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : LED1_Pin LED2_Pin */
	GPIO_InitStruct.Pin = LED1_Pin | LED2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure GPIO pin : MET_PWR_ENABLE_Pin */
	GPIO_InitStruct.Pin = MET_PWR_ENABLE_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	HAL_GPIO_Init(MET_PWR_ENABLE_GPIO_Port, &GPIO_InitStruct);

	/* USER CODE BEGIN MX_GPIO_Init_2 */
	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*
void process_metal_detection(void) {
    if (MET_ETH_Var) {
        adc_avg = adc_sum = 0;
        for (int i = 0; i < 200; i++) {
            HAL_ADC_Start(&hadc1);
            if (HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY) == HAL_OK) {
                adc_value = HAL_ADC_GetValue(&hadc1);
                adc_sum += adc_value;
            }
            HAL_ADC_Stop(&hadc1);
        }

        adc_avg = adc_sum / 200;
        filtered_value = apply_weighted_filter(adc_value);
        map_met = (uint8_t) map(filtered_value, 2150, 3163, 0, 100);

        if (map_met > 100) map_met = 100;
        if (map_met < 0) map_met = 0;

        if (map_met >= 0 && map_met <= 20) {
            MetalV = map(map_met, 0, 20, 300, 360);
        } else if (map_met > 20 && map_met <= 50) {
            MetalV = map(map_met, 21, 50, 0, 90);
        } else if (map_met > 50 && map_met <= 80) {
            MetalV = map(map_met, 51, 80, 91, 180);
        } else if (map_met > 80 && map_met <= 100) {
            MetalV = map(map_met, 81, 100, 181, 245);
        }

        if (MetalV != prev_MetalV || map_met != prev_map_met) {
            sendToMetalDetector("Metal.val", MetalV);
            sendToMetalDetector("Value.val", map_met);
            prev_MetalV = MetalV;
            prev_map_met = map_met;
        }
    } else {
        if (!zeroSent_Metal) {
            sendToMetalDetector("Metal.val", 300);  //adjustment in scaling
            sendToMetalDetector("Value.val", 0);
            zeroSent_Metal = true;
        }
    }
}
*/

// function to determine the adaptive difference based on the ADC value
int adaptive_diff(int adc_value) {
    // higher ADC values (e.g., 2600+) get smaller diff, lower values (e.g., ~1800) get larger diff
    if (adc_value > 2600) {
        return 50;  // small allowed difference for high ADC values
    } else if (adc_value < 1800) {
        return 300; // large allowed difference for low ADC values
    } else {
        // calculate allowed difference based on ADC value in the middle range
        return 300 - ((adc_value - 1800) * (300 - 50)) / (2600 - 1800);
    }
}

int adaptive_diff(int adc_value);

// function to reject abrupt change
int reject_outliers(int current_value, int previous_value, int diff_from_prv_val) {
    int diff = abs(current_value - previous_value);
    float weight = (diff > diff_from_prv_val) ? (float)diff_from_prv_val / diff : 1.0;
    return (int)(previous_value * (1.0 - weight) + current_value * weight);
}

// function to process metal detection logic based on ADC values
void process_metal_detection(void) {
    if (MET_ETH_Var) {
        adc_avg = adc_sum = 0;

        for (int i = 0; i < 200; i++) {
            HAL_ADC_Start(&hadc1); // start ADC conversion
            if (HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY) == HAL_OK) {
                adc_value = HAL_ADC_GetValue(&hadc1);

                // apply adaptive difference filter based on ADC value
                int allowed_diff = adaptive_diff(adc_value);

                // reject values that are outside the allowed difference range
                if (i > 0 && abs(adc_value - adc_prev_value) > allowed_diff) {
                    adc_value = reject_outliers(adc_value, adc_prev_value, allowed_diff); // apply outlier rejection
                }

                // update previous ADC value for the next iteration
                adc_prev_value = adc_value;

                adc_sum += adc_value;
            }
            HAL_ADC_Stop(&hadc1);
        }

        adc_avg = adc_sum / 200;

        if (adc_avg < 2150) adc_avg = 2150;
        map_met = (uint8_t) map(adc_avg, 2150, 3163, 0, 100);

        if (map_met > 100) map_met = 100;
        if (map_met < 0) map_met = 0;

        if (map_met >= 0 && map_met <= 20) {
            MetalV = map(map_met, 0, 20, 300, 360);
        } else if (map_met > 20 && map_met <= 50) {
            MetalV = map(map_met, 21, 50, 0, 90);
        } else if (map_met > 50 && map_met <= 80) {
            MetalV = map(map_met, 51, 80, 91, 180);
        } else if (map_met > 80 && map_met <= 100) {
            MetalV = map(map_met, 81, 100, 181, 245);
        }

        if (MetalV != prev_MetalV || map_met != prev_map_met) {
            sendToMetalDetector("Metal.val", MetalV);
            sendToMetalDetector("Value.val", map_met);
            prev_MetalV = MetalV;
            prev_map_met = map_met;
        }
    } else {
        if (!zeroSent_Metal) {
            sendToMetalDetector("Metal.val", 300);  // adjust scaling when no metal is detected
            sendToMetalDetector("Value.val", 0);
            zeroSent_Metal = true;
        }
    }
}

void process_battery_level(void) {
    if (bt_flag) {
        stabilize_oscillations_in_battery(&variable1);
        if (variable1 != prev_variable1) {
            sendToBatterylevel("Battery.val", variable1);
            sendToBatteryPercentage("battery.txt", variable1);
            prev_variable1 = variable1;
        }
    } else {
        if (!zeroSent) {
            sendToBatterylevel("Battery.val", 0);
            sendToBatteryPercentage("battery.txt", 0);
            zeroSent = true;
        }
    }
}

void process_depth_measurement(void) {
    if (depth_flag) {
        sendToDepth("Depth.txt", Depth_value);
    } else {
        if (!zeroSent_Depth) {
            sendToDepth("Depth.txt", "0");
            zeroSent_Depth = true;
        }
    }
}

void process_altitude_measurement(void) {
    if (dist_flag) {
        sendToAltitude("Altitude.txt", Dist_value);
    } else {
        if (!zeroSent_Dist) {
            sendToAltitude("Altitude.txt", "0");
            zeroSent_Dist = true;
        }
    }
}

void check_leak_detection(void) {
    leakDetected = HAL_GPIO_ReadPin(LEAK_PIN_GPIO_Port, LEAK_PIN_Pin);
    if (leakDetected == GPIO_PIN_SET) {
        sendToLeak("va0.val", 1);
    } else {
        sendToLeak("va0.val", 0);
    }
}

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

