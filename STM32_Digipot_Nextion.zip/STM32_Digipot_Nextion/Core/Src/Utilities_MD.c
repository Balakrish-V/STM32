/*
 * ADC_fns_MD.c
 *
 *  Created on: Feb 3, 2025
 *      Author: user
 */

#include "main.h"
#include "Utilities_MD.h"

extern bool MET_ETH_Var;

int map(int x, int in_min, int in_max, int out_min, int out_max) {
	return (int) ((float) (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min);
}

void set_gpio_high(void) {
	MET_ETH_Var = 1;
	HAL_GPIO_WritePin(MET_PWR_ENABLE_GPIO_Port, MET_PWR_ENABLE_Pin,MET_ETH_Var);
}

void set_gpio_low(void) {
	MET_ETH_Var = 0;
	HAL_GPIO_WritePin(MET_PWR_ENABLE_GPIO_Port, MET_PWR_ENABLE_Pin,MET_ETH_Var);
}
