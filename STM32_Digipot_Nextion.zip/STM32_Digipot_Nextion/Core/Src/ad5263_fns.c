/*
 * ad5263_fns.c
 *
 *  Created on: Jan 20, 2025
 *      Author: user
 */

#include "ad5263_header.h"

#include "main.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern UART_HandleTypeDef huart4;

extern UART_HandleTypeDef huart5;

extern I2C_HandleTypeDef hi2c3;

extern AD5263_t potentiometer;

void printf_uart(UART_HandleTypeDef *huart, const char *string) {
    HAL_UART_Transmit(huart, (uint8_t*) string, strlen(string), HAL_MAX_DELAY);
}

void I2C_Scan(I2C_HandleTypeDef *hi2c) {
	char message[50];
	PRINT_UART4("Scanning I2C...\r\n");  // --> This will send data via Ethernet
	for (uint8_t address = 1; address < 127; address++) {
		HAL_StatusTypeDef result = HAL_I2C_IsDeviceReady(hi2c,(uint16_t) (address << 1), 1, HAL_MAX_DELAY);
		if (result == HAL_OK) {
			snprintf(message, sizeof(message),"I2C device found at address: 0x%02X\r\n", address);
			PRINT_UART4(message);
		}
	}
	PRINT_UART4("Scan complete.\r\n");
}

void AD5263_I2C_Init(void) {
	HAL_GPIO_WritePin(DIS_GPIO_Port, DIS_Pin, 1);  //I2C
	HAL_Delay(100);
	HAL_GPIO_WritePin(AD0_GPIO_Port, AD0_Pin, 1);
	HAL_GPIO_WritePin(AD1_GPIO_Port, AD1_Pin, 1);
	HAL_Delay(100);

	potentiometer.hi2c = &hi2c3;     // Point to your I2C handle
	potentiometer.address = 0x2F;    // Set the correct I2C address
	//I2C_Scan(potentiometer.hi2c);  // Use this for debugging
}

uint8_t AD5263_Reset(AD5263_t *pot) {
    return AD5263_SetAll(pot, 0);
}

uint8_t AD5263_SetAll(AD5263_t *pot, const uint8_t value) {
    for (uint8_t i = 0; i < 4; i++) {
        HAL_Delay(500);
        if (AD5263_Write(pot, i, value) != 0) {
            char message[50];
            snprintf(message, sizeof(message), "Failed to set RDAC %d to %d\r\n", i, value);
            PRINT_UART4(message);
            return AD5263_ERROR;
        }
    }
    char message[50];
    snprintf(message, sizeof(message), "Set all RDACs to value: %d\r\n", value);
    PRINT_UART4(message);
    return 0;
}

uint8_t AD5263_Write(AD5263_t *pot, const uint8_t rdac, const uint8_t value) {
    if (rdac >= 4)
        return AD5263_ERROR;

    uint8_t cmd = (rdac == 0) ? AD5263_RDAC0 : (rdac == 1) ? AD5263_RDAC1 :
                  (rdac == 2) ? AD5263_RDAC2 : AD5263_RDAC3;
    pot->lastValue[rdac] = value;

    uint8_t data[2] = { cmd, value };
    HAL_StatusTypeDef status = HAL_I2C_Master_Transmit(pot->hi2c, pot->address << 1, data, 2, HAL_MAX_DELAY); // Shift address left for 7-bit
    if (status != HAL_OK) {
        char message[50];
        snprintf(message, sizeof(message), "I2C Write Error: %d while writing to RDAC %d\r\n", status, rdac);
        //PRINT_UART4(message);
        return AD5263_ERROR;
    }
    return 0; // Success
}

uint8_t AD5263_ShutDown(AD5263_t *pot) {
    for (uint8_t i = 0; i < 4; i++) {
        uint8_t cmd = (i == 0) ? AD5263_RDAC0 : (i == 1) ? AD5263_RDAC1 :
                      (i == 2) ? AD5263_RDAC2 : AD5263_RDAC3;
        cmd |= AD5263_SHUTDOWN; // Combine the shutdown command
        if (AD5263_Write(pot, i, 0) != 0) {
            char message[50];
            snprintf(message, sizeof(message), "Failed to shut down RDAC %d\r\n", i);
            PRINT_UART4(message);
            return AD5263_ERROR;
        }
    }
    PRINT_UART4("All RDACs shut down\r\n");
    return 0; // Success
}

uint8_t AD5263_Read(AD5263_t *pot, const uint8_t rdac) {
    if (rdac >= 4)
        return 0x00;
    return pot->lastValue[rdac];
}

// the below function to use the DigiPot using AD5263

int parse_uart_data(const char *data, uint8_t *range, uint8_t *delay) {
	if (data == NULL || range == NULL || delay == NULL || strlen(data) == 0) {
		return -1;
	}

	if (strlen(data) != 7) {
		return -1;
	}

	char range_str[4] = { 0 }, delay_str[4] = { 0 };

	strncpy(range_str, data, 3);      // First 3 characters for range
	strncpy(delay_str, data + 4, 3);  // Next 3 characters for delay

	range_str[3] = '\0';
	delay_str[3] = '\0';

	int range_val = atoi(range_str);
	int delay_val = atoi(delay_str);

	if (range_val < RANGE_VAR_MIN || range_val > RANGE_VAR_MAX
			|| delay_val < DELAY_VAR_MIN || delay_val > DELAY_VAR_MAX) {
		return -2;
	}

	*range = (uint8_t) range_val;
	*delay = (uint8_t) delay_val;

	return 0;
}

// To control the range and delay of metal detector board using UART4 via Ethernet
// The commands should be in the following format
/*
 e.g :-
 * RANGE(in 3 digits);DELAY(in 3 digits)
 * 255;255
 * 001;255
 * 255;001
 */
