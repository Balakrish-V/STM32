/*
 * Nextion_hdrs.h
 *
 *  Created on: Jan 20, 2025
 *      Author: user
 */

#ifndef INC_NEXTION_HDRS_H_
#define INC_NEXTION_HDRS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

void Nextion_init(char *obj, uint8_t value);
void sendToMetalDetector(char *obj, uint16_t value);
void sendToBatterylevel(char *obj, uint16_t value);
void sendToBatteryPercentage(char *obj, uint16_t value);
void sendToLeak(char *obj, uint16_t value);
void sendToDepth(char *obj,char *value);
void sendToAltitude(char *obj,char *value);

#endif /* INC_NEXTION_HDRS_H_ */
