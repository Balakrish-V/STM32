/*
 * ADC_Related_MD_fns.h
 *
 *  Created on: Feb 3, 2025
 *      Author: user
 */

#ifndef INC_UTILITIES_MD_H_
#define INC_UTILITIES_MD_H_

#include "stdio.h"
#include "string.h"
#include "stdbool.h"

// Function Prototypes
int map(int x, int in_min, int in_max, int out_min, int out_max);
int apply_weighted_filter(int new_sample);
void set_gpio_high(void);
void set_gpio_low(void);


#define FILTER_SIZE 6  // Define the filter size
#define ADC_BUFFER_SIZE FILTER_SIZE

#endif /* INC_UTILITIES_MD_H_ */
