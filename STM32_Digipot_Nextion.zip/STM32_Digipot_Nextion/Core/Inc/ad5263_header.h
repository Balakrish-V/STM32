/*
 * ad5263_header.h
 *
 *  Created on: Jan 20, 2025
 *      Author: user
 */

#ifndef AD5263_H
#define AD5263_H

#include "main.h"
#include "stm32f4xx_hal.h"  // Include for HAL types

#define RX_BUFFER_SIZE 7 // RANGE;DELAY

//AD5263_Range_corrections
#define RANGE_VAR_MIN 0
#define RANGE_VAR_MAX 255
#define DELAY_VAR_MIN 0
#define DELAY_VAR_MAX 255

// Define error code
#define AD5263_ERROR 1

// Define shutdown command for RDACs
#define AD5263_SHUTDOWN 0x10

// Define RDAC command values
#define AD5263_RDAC0 0x00
#define AD5263_RDAC1 0x01
#define AD5263_RDAC2 0x02
#define AD5263_RDAC3 0x03

// AD5263 structure for potentiometer
typedef struct {
	I2C_HandleTypeDef *hi2c;  // I2C handle
	uint8_t address;          // I2C address of the device
	uint8_t lastValue[4];     // Stores last set values of the RDACs
} AD5263_t;

void I2C_Scan(I2C_HandleTypeDef *hi2c);
// Function declarations
void AD5263_I2C_Init(void);
uint8_t AD5263_Reset(AD5263_t *pot);
uint8_t AD5263_SetAll(AD5263_t *pot, const uint8_t value);
uint8_t AD5263_Write(AD5263_t *pot, const uint8_t rdac, const uint8_t value);
uint8_t AD5263_ShutDown(AD5263_t *pot);
uint8_t AD5263_Read(AD5263_t *pot, const uint8_t rdac);

// Function to send formatted strings via UART
void printf_uart(UART_HandleTypeDef *huart, const char *string);

#define PRINT_UART4(message) printf_uart(&huart4, message)   // ->DEBUG/ETHERNET -> FOR BATTERY
#define PRINT_UART5(message) printf_uart(&huart5, message)   // ->NEXTION DISPLAY

int parse_uart_data(const char *data, uint8_t *range, uint8_t *delay);

#endif /* AD5263_H */

